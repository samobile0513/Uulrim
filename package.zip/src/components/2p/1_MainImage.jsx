import React from 'react';

const MainImage = () => {
  return (
    <div className="relative w-full h-[500px] overflow-hidden flex justify-center items-center">
      <img 
        src="/2p/2_main.svg" 
        alt="2페이지 메인 이미지" 
        className="min-w-[1920px] h-full object-cover"
      />
    </div>
  );
};

export default MainImage;
