import React from 'react';
import { Link } from 'react-router-dom';

const menuItems = [
  { label: '어울림이란', path: '/' },
  { label: '장애인고용부담금이란', path: '/1' },
  { label: '생산물품구매', path: '/2' },
  { label: '교육&엔터서비스', path: '/3' },
  { label: '동행하는 사람들', path: '/4' },
];

const MobileNavMenu = ({ onClose }) => {
  return (
    <div className="fixed top-0 right-0 w-[393px] h-screen bg-[#00A9A4] z-50 flex flex-col px-[25px] pt-[30px]">
      <img src="/Mtitle.svg" alt="logo" className="w-[90px] mb-[40px]" />

      <nav className="flex flex-col gap-[18px]">
        {menuItems.map((item, idx) => (
          <Link
            key={idx}
            to={item.path}
            onClick={onClose}
            style={{
              fontFamily: 'Paperlogy-6SemiBold',
              fontSize: '16.08px',
            }}
            className="text-white hover:text-[#FFD400] transition-colors duration-200"
          >
            {item.label}
          </Link>
        ))}
      </nav>
    </div>
  );
};

export default MobileNavMenu;
