import { Outlet, useLocation } from 'react-router-dom';
import Header from "../components/1_header";
import NavMenu from "../components/2_NavMenu";
import Footer from "../components/3_Footer";

import { useEffect, useRef, useState } from 'react';

const Layout = () => {
  const [scale, setScale] = useState(1);
  const [isMobile, setIsMobile] = useState(false);
  const [contentHeight, setContentHeight] = useState(null);
  const { pathname } = useLocation();
  const scrollContainerRef = useRef();
  const contentRef = useRef();
  const outletRef = useRef();

  useEffect(() => {
    if (window.__isModalOpen) {
      console.log("Layout: Scroll reset skipped due to open modal, pathname:", pathname);
      return;
    }

    if (scrollContainerRef.current) {
      console.log("Layout: Scroll reset executed, pathname:", pathname);
      scrollContainerRef.current.scrollTop = 0;
    }
  }, [pathname]);

  useEffect(() => {
    const handleResize = () => {
      const screenWidth = window.innerWidth;
      console.log("Layout: Screen width:", screenWidth, "Scale:", scale);
      if (screenWidth <= 1200) {
        setIsMobile(true);
        setScale(screenWidth / 1200);
      } else {
        setIsMobile(false);
        if (screenWidth >= 1920) {
          setScale(screenWidth / 1920);
        } else {
          setScale(1);
        }
      }
    };

    window.addEventListener('resize', handleResize);
    handleResize();
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  useEffect(() => {
    const updateContentHeight = () => {
      if (outletRef.current) {
        const outletHeight = outletRef.current.getBoundingClientRect().height;
        console.log("Layout: Outlet height:", outletHeight);
        setContentHeight(outletHeight);
      }
    };

    if (isMobile) {
      const resizeObserver = new ResizeObserver(updateContentHeight);
      if (outletRef.current) {
        resizeObserver.observe(outletRef.current);
      }
      setTimeout(updateContentHeight, 50);
      return () => {
        if (outletRef.current) {
          resizeObserver.unobserve(outletRef.current);
        }
      };
    } else {
      setContentHeight(null);
    }
  }, [isMobile, scale, pathname]);

  const OutletWrapper = () => {
    return (
      <div ref={outletRef}>
        <Outlet />
      </div>
    );
  };

  return (
    <div className="min-h-screen flex flex-col overflow-hidden">
      <Header className="fixed top-0 left-0 w-full z-50" />
      <NavMenu className="fixed top-[80px] left-0 w-full z-40" />
      <div
        ref={scrollContainerRef}
        className="flex-1 flex justify-center items-start overflow-x-hidden overflow-y-auto bg-white"
        style={{
          height: isMobile && contentHeight ? `calc(${contentHeight}px * ${scale})` : 'auto',
        }}
      >
        <div
          ref={contentRef}
          className="flex justify-center w-full"
          style={{
            height: isMobile && contentHeight ? `calc(${contentHeight}px * ${scale})` : 'auto',
          }}
        >
          <div
            className="flex flex-col w-full"
            style={{
              width: '1920px',
              transform: `scale(${scale})`,
              transformOrigin: 'top center',
              minHeight: isMobile ? '100%' : 'auto',
            }}
          >
            <div style={{ paddingTop: `calc(142.78px / ${scale})` }}>
              <OutletWrapper />
            </div>
            <Footer />
 
          </div>
        </div>
      </div>
    </div>
  );
};

export default Layout;