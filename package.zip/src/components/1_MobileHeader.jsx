import React, { useState } from 'react';
import MobileNavMenu from './2_MobileNavMenu';

const MobileHeader = () => {
  const [open, setOpen] = useState(false);

  return (
    <div className="block md:hidden">
      {/* 상단 모바일 배너 */}
      <div className="w-[393px] h-[52px] bg-[#00A9A4] mx-auto flex flex-col items-center justify-center">
        <span style={{ fontFamily: 'Paperlogy-4Regular' }} className="text-white text-[15px] leading-[18px]">
          장애인 고용부담금 감면
        </span>
        <span style={{ fontFamily: 'Paperlogy-7Bold' }} className="text-[#FFD400] text-[20px] leading-[20px] font-bold">
          지금 문의하기 <span className="text-white">{`>`}</span>
        </span>
      </div>

      {/* 로고 + 햄버거 영역 */}
      <div className="w-[393px] h-[65px] mx-auto relative flex items-start justify-between pt-[17px]">
        <img src="/Mtitle.svg" alt="logo" className="ml-[23px] w-[100px]" />
        <button onClick={() => setOpen(!open)} className="mr-[34px]">
          <img src="/Mburger.svg" alt="menu" className="w-[26px]" />
        </button>
      </div>

      {/* 햄버거 클릭 시 메뉴 표시 */}
      {open && <MobileNavMenu onClose={() => setOpen(false)} />}
    </div>
  );
};

export default MobileHeader;
