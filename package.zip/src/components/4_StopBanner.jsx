import React from 'react';
import { useEffect, useState } from 'react';

const StopBanner = () => {
  const [isMobile, setIsMobile] = useState(false);

  useEffect(() => {
    const checkMobile = () => setIsMobile(window.innerWidth <= 839);
    checkMobile(); // 초기 체크
    window.addEventListener('resize', checkMobile);
    return () => window.removeEventListener('resize', checkMobile);
  }, []);

  return (
    <div className="fixed top-[310px] right-[20px] z-50">
{isMobile ? (
  <div className="fixed top-[310px] right-[20px] z-50 flex flex-col items-end space-y-4">
    <img
      src="/mobile_stop_banner_1.svg"
      alt="모바일 배너1"
      className="block max-w-[84px] w-[30vw] h-auto"
    />
    <img
      src="/mobile_stop_banner_2.svg"
      alt="모바일 배너2"
      className="block max-w-[84px] w-[30vw] h-auto"
    />
  </div>
) : (
        // ✅ 기존 데스크탑 배너
        <div className="flex flex-col items-center">
          <a href="https://www.naver.com" target="_blank" rel="noopener noreferrer" className="group mb-[20px]">
            <img src="/stop_banner_1.svg" alt="배너1" />
          </a>
          <a href="https://www.naver.com" target="_blank" rel="noopener noreferrer" className="group mb-[20px]">
            <img src="/stop_banner_2.svg" alt="배너2" />
          </a>
          <a href="https://www.naver.com" target="_blank" rel="noopener noreferrer" className="group mb-[20px]">
            <img src="/stop_banner_3.svg" alt="배너3" />
          </a>
          <a href="https://www.naver.com" target="_blank" rel="noopener noreferrer" className="group">
            <img src="/stop_banner_4.svg" alt="배너4" />
          </a>
        </div>
      )}
    </div>
  );
};

export default StopBanner;
