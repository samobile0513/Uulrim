import React, { useState } from 'react';
import TermsModal from './TermsModal';
import Info1 from './other/info1';
import Info2 from './other/info2';
import Info3 from './other/info3';

const Footer = () => {
  const [openModal, setOpenModal] = useState(null); // "info1" | "info2" | "info3"

  return (
    <div className="w-full flex flex-col items-center pt-[50px] pb-[50px]" style={{ backgroundColor: '#3D3D3D' }}>
      <div className="w-full flex flex-col items-start" style={{ paddingLeft: '369px' }}>
        {/* footer.svg */}
        <img src="/footer.svg" alt="footer-logo" />

        {/* 여백 30px */}
        <div className="mt-[0px] flex items-center">
          {/* footer1.svg (서비스 이용약관 모달) */}
          <div
            onClick={() => setOpenModal('info1')}
            className="hover:opacity-80 transition-all duration-300 mr-[14px] cursor-pointer"
          >
            <img src="/footer1.svg" alt="서비스 이용약관" />
          </div>

          {/* footerline.svg */}
          <img src="/footerline.svg" alt="line1" className="mr-[14px]" />

          {/* footer2.svg (개인정보 처리방침 모달) */}
          <div
            onClick={() => setOpenModal('info2')}
            className="hover:opacity-80 transition-all duration-300 mr-[14px] cursor-pointer"
          >
            <img src="/footer2.svg" alt="개인정보 처리방침" />
          </div>

          {/* footerline.svg */}
          <img src="/footerline.svg" alt="line2" className="mr-[14px]" />

          {/* footer3.svg (마케팅 정보 수신동의 모달) */}
          <div
            onClick={() => setOpenModal('info3')}
            className="hover:opacity-80 transition-all duration-300 cursor-pointer"
          >
            <img src="/footer3.svg" alt="마케팅 정보 수신동의" />
          </div>
        </div>

        {/* 여백 10px */}
        <div className="mt-[10px]" />

        {/* footerend.svg */}
        <img src="/footerend.svg" alt="footer-end" />
      </div>

      {/* 모달 */}
      <TermsModal isOpen={openModal === 'info1'} onClose={() => setOpenModal(null)}>
        <Info1 />
      </TermsModal>
      <TermsModal isOpen={openModal === 'info2'} onClose={() => setOpenModal(null)}>
        <Info2 />
      </TermsModal>
      <TermsModal isOpen={openModal === 'info3'} onClose={() => setOpenModal(null)}>
        <Info3 />
      </TermsModal>
    </div>
  );
};

export default Footer;