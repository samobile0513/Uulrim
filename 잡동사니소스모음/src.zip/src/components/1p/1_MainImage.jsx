import React, { useEffect } from 'react';

const MainImage = () => {
  useEffect(() => {
    console.log('MainImage: Component mounted');
  }, []);

  return (
    <div className="relative w-full h-[500px] overflow-hidden flex justify-center items-center">
      <img 
        src="/1p/1main.svg" 
        alt="1페이지 메인 이미지" 
        className="w-[1920px] h-full object-cover main-image"
        onError={() => console.error('MainImage: Failed to load /1p/1main.svg')}
        onLoad={() => console.log('MainImage: Image loaded successfully')}
      />
    </div>
  );
};

export default MainImage;