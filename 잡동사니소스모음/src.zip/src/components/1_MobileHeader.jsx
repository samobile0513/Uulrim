import React, { useState } from 'react';
import MobileNavMenu from './MobileNavMenu'; // 아래에서 만들 것
import menuIcon from '/Mburger.svg';
import logoIcon from '/Mtitle.svg';

const MobileHeader = () => {
  const [open, setOpen] = useState(false);

  return (
    <>
      <div className="w-[393px] h-[65px] mx-auto relative flex items-start justify-between pt-[17px]">
        <img src={logoIcon} alt="logo" className="ml-[23px] w-[80px]" />
        <button onClick={() => setOpen(!open)} className="mr-[34px]">
          <img src={menuIcon} alt="menu" className="w-[26px]" />
        </button>
      </div>
      {open && <MobileNavMenu onClose={() => setOpen(false)} />}
    </>
  );
};

export default MobileHeader;
