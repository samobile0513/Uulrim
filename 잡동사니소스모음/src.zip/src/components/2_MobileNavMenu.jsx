import React from 'react';
import { Link } from 'react-router-dom';
import logoIcon from '/Mtitle.svg';

const menuItems = [
  { label: '어울림이란', path: '/' },
  { label: '장애인고용부담금이란', path: '/1page' },
  { label: '생산물품구매', path: '/2page' },
  { label: '교육&엔터서비스', path: '/3page' },
  { label: '동행하는 사람들', path: '/4page' },
];

const MobileNavMenu = ({ onClose }) => {
  return (
    <div className="fixed top-0 right-0 w-[393px] h-screen bg-[#00A9A4] z-50 flex flex-col items-start px-[25px] pt-[30px]">
      <img src={logoIcon} alt="logo" className="w-[90px] mb-[40px]" />
      <nav className="flex flex-col gap-[18px] text-white text-[16.08px] font-bold">
        {menuItems.map((item, idx) => (
          <Link
            key={idx}
            to={item.path}
            onClick={onClose}
            className="hover:text-[#FFD400] transition-colors duration-200"
          >
            {item.label}
          </Link>
        ))}
      </nav>
    </div>
  );
};

export default MobileNavMenu;
