import React from 'react';

const BuySection = () => {
  return (
    <div className="w-full flex flex-col items-center pt-[100px]">
      <div className="w-full flex flex-col items-center">
        <div className="mt-[10px]" />
      </div>
    </div>
  );
};

export default BuySection;
