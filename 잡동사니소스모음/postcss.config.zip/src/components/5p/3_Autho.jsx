import React from 'react';

const CharacterSection = () => {
  return (
    <div className="w-full flex flex-col items-center pt-[100px]">
      <div className="w-full flex flex-col items-center">
        <img src="/5p/5_4.svg" alt="5_4" />
      </div>
    </div>
  );
};

export default CharacterSection;
