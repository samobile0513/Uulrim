import React from 'react';

const StopBanner = () => {
  return (
    <div
      className="fixed top-[200px] right-[30px] z-50"
    >
      <div className="flex flex-col items-center">
        {/* 배너들 */}
        <a href="https://www.naver.com" target="_blank" rel="noopener noreferrer" className="group mb-[20px]">
          <img src="/stop_banner_1.svg" alt="배너1" />
        </a>
        <a href="https://www.naver.com" target="_blank" rel="noopener noreferrer" className="group mb-[20px]">
          <img src="/stop_banner_2.svg" alt="배너2" />
        </a>
        <a href="https://www.naver.com" target="_blank" rel="noopener noreferrer" className="group mb-[20px]">
          <img src="/stop_banner_3.svg" alt="배너3" />
        </a>
        <a href="https://www.naver.com" target="_blank" rel="noopener noreferrer" className="group">
          <img src="/stop_banner_4.svg" alt="배너4" />
        </a>
      </div>
    </div>
  );
};

export default StopBanner;
