import React from "react";
import ReactDOM from "react-dom/client";
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Layout from "./components/0_Layout";
import HomePage from "./pages/HomePage";
import SecondPage from "./pages/2Page";
import ThirdPage from "./pages/3Page";
import FourPage from "./pages/4Page";
import Survey from "./components/Survey";
import StopBanner from "./components/4_StopBanner"; // ✅ 다시 여기로

import "./index.css";

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <Router>
      <StopBanner /> {/* ✅ Layout 바깥에 독립적으로 띄우기 */}
      <Routes>
        <Route element={<Layout />}>
          <Route path="/" element={<HomePage />} />
          <Route path="/2page" element={<SecondPage />} />
          <Route path="/3page" element={<ThirdPage />} />
          <Route path="/4page" element={<FourPage />} />
          <Route path="/survey" element={<Survey />} />
        </Route>
      </Routes>
    </Router>
  </React.StrictMode>
);
