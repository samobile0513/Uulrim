import { Outlet } from 'react-router-dom';
import Header from "../components/1_Header";
import NavMenu from "../components/2_NavMenu";
import Footer from "../components/3_Footer";
import { useEffect, useState } from 'react';

const Layout = () => {
  const [scale, setScale] = useState(1);

  useEffect(() => {
    const handleResize = () => {
      const screenWidth = window.innerWidth;
      if (screenWidth >= 1920) {
        setScale(screenWidth / 1920); // 화면 크기 비례
      } else {
        setScale(1);
      }
    };

    window.addEventListener('resize', handleResize);
    handleResize();

    return () => window.removeEventListener('resize', handleResize);
  }, []);

  return (
    <>
      {/* 고정 Header */}
      <Header className="fixed top-0 left-0 w-full z-50" />

      {/* 고정 NavMenu */}
      <NavMenu className="fixed top-[80px] left-0 w-full z-40" />

      {/* Layout 내에서만 scale 적용 */}
      <div className="w-screen min-h-screen flex flex-col items-center overflow-x-hidden bg-white relative">
        <div
          className="origin-top"
          style={{
            width: '1920px',
            transform: `scale(${scale})`, // 본문 내용만 scale 적용
            transformOrigin: 'top center',
          }}
        >
          <div className="pt-[136px]"> {/* 상단 여백을 Header + NavMenu 높이만큼 추가 */}
            <Outlet /> {/* 본문 내용 */}
          </div>
          <Footer />
        </div>
      </div>
    </>
  );
};

export default Layout;
