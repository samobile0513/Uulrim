import React from 'react';

const AboutSection = () => {
  return (
    <div className="w-full flex flex-col items-center pt-[40px]">
      <div className="w-full flex flex-col items-center">
        <img src="/1p/1_31.svg" alt="메인이미지" />
        <div className="mt-[120px]" />
        <img src="/1p/1_32.svg" alt="1_32" />
        <div className="mt-[49px]" />
        <img src="/1p/1_33.svg" alt="1_33" />
        <div className="mt-[145px]" />
        <img src="/1p/1_34.svg" alt="1_34" />

        <div className="mt-[9px] relative flex justify-center w-full">
          <img src="/1p/1_35.svg" alt="최저시급 문구" className="relative left-[190px]" />
        </div>

        <div className="mt-[62px]" />
        <img src="/1p/1_36.svg" alt="1_36" />
        <div className="mt-[40px]" />
        <img src="/1p/1_37.svg" alt="1_37" />
        <div className="mt-[101px]" />
        <img src="/1p/1_38.svg" alt="1_38" />
        <div className="mt-[49px]" />
        <img src="/1p/1_39.svg" alt="1_39" />
        <div className="mt-[47px]" />
      </div>
    </div>
  );
};

export default AboutSection;
