import React from 'react';

const MainSection = () => {
  return (
    <div className="w-[1920px] origin-top scale-custom mx-auto flex flex-col items-center pt-[87px]">
      
      {/* 전체 1920px 박스 (scale 대상) */}
      <div className="w-full flex flex-col items-center">

        {/* 중앙 790x351 박스 */}
        <div className="w-[790px] h-[351px] relative flex flex-col items-center">
          
          {/* 1_21.svg (어울림이란) */}
          <img src="/1p/1_21.svg" alt="어울림이란" />

          {/* 왼쪽 1_22.svg + 오른쪽 1_23.svg */}
          <div className="w-full relative flex justify-between">
            {/* 왼쪽 1_22.svg */}
            <img 
              src="/1p/1_22.svg" 
              alt="왼쪽 이미지" 
              className="absolute left-0 top-[58px]"
            />
            {/* 오른쪽 1_23.svg */}
            <img 
              src="/1p/1_23.svg" 
              alt="오른쪽 이미지" 
              className="absolute right-0 top-[38px] z-10"
            />
          </div>

        </div>

        {/* 23px 여백 후 1_24.svg */}
        <div className="mt-[23px] w-[790px] flex justify-start">
          <img src="/1p/1_24.svg" alt="왼쪽 정렬된 중앙 밑 박스" />
        </div>

        {/* 44px 여백 후 1_25.svg */}
        <div className="mt-[44px] flex justify-center w-full">
          <img src="/1p/1_25.svg" alt="맨 아래 박스" />
        </div>

      </div>
      
    </div>
  );
};

export default MainSection;
