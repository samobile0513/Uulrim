import React from 'react';

const Footer = () => {
  return (
    <div className="w-full flex flex-col items-center pt-[50px] pb-[50px]" style={{ backgroundColor: '#3D3D3D' }}>
      <div className="w-full flex flex-col items-start" style={{ paddingLeft: '369px' }}>
        {/* footer.svg */}
        <img src="/footer.svg" alt="footer-logo" />

        {/* 여백 30px */}
        <div className="mt-[30px] flex items-center">

          {/* footer1.svg (링크) */}
          <a href="https://www.naver.com" className="hover:opacity-80 transition-all duration-300 mr-[14px]">
            <img src="/footer1.svg" alt="footer1" />
          </a>

          {/* footerline.svg */}
          <img src="/footerline.svg" alt="line1" className="mr-[14px]" />

          {/* footer2.svg (링크) */}
          <a href="https://www.naver.com" className="hover:opacity-80 transition-all duration-300 mr-[14px]">
            <img src="/footer2.svg" alt="footer2" />
          </a>

          {/* footerline.svg */}
          <img src="/footerline.svg" alt="line2" className="mr-[14px]" />

          {/* footer3.svg (링크) */}
          <a href="https://www.naver.com" className="hover:opacity-80 transition-all duration-300">
            <img src="/footer3.svg" alt="footer3" />
          </a>

        </div>

        {/* 여백 10px */}
        <div className="mt-[10px]" />

        {/* footerend.svg */}
        <img src="/footerend.svg" alt="footer-end" />
      </div>
    </div>
  );
};

export default Footer;
