import React from 'react';

const PurchaseFromStandardBusiness = () => {
  return (
    <div className="w-full flex flex-col items-center pt-[136px]">
      <img src="/2p/2_41.svg" alt="2_41" />
      <div className="mt-[130px]" />
      <img src="/2p/2_42.svg" alt="2_42" className="transform translate-x-[330px]" />
      <div className="mt-[60px]" />
      <img src="/2p/2_43.svg" alt="2_43" />
      <div className="mt-[90px]" />
    </div>
  );
};

export default PurchaseFromStandardBusiness;