import React from "react";

const Edu1 = () => {
  return (
    <div
      className="w-full"
      style={{
        backgroundColor: "#E6F4F4",
        width: "1920px",
        height: "820px",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        paddingTop: "65px",
      }}
    >
      {/* 4_title.svg */}
      <img src="/4p/4_title.svg" alt="Title" />

      {/* 65px 여백 */}
      <div style={{ height: "65px" }} />

      {/* 4_1.svg */}
      <img src="/4p/4_1.svg" alt="Content" />

      {/* 132px 여백 */}
      <div style={{ height: "132px" }} />
    </div>
  );
};

export default Edu1;
