import React from "react";

const End = () => {
  return (
    <div
      className="w-full"
      style={{
        width: "1920px",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        paddingTop: "160px",
      }}
    >
      {/* 4_end.svg */}
      <img src="/4p/4_end.svg" alt="End" />

      {/* 372px 여백 */}
      <div style={{ height: "372px" }} />
    </div>
  );
};

export default End;
