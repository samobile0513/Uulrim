import React from "react";

const Edu2 = () => {
  return (
    <div
      className="w-full"
      style={{
        backgroundColor: "#E6F4F4",
        width: "1920px",
        height: "1262px",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        paddingTop: "105px",
      }}
    >
      {/* 4_title.svg */}
      <img src="/4p/45_title.svg" alt="Title" />

      {/* 65px 여백 */}
      <div style={{ height: "105px" }} />

      {/* 4_2.svg */}
      <img src="/4p/4_5.svg" alt="Content" />

      {/* 132px 여백 */}
      <div style={{ height: "132px" }} />
    </div>
  );
};

export default Edu2;
